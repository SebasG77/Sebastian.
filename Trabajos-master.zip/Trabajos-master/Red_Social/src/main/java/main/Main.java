package main;


import view.Vista;

/**
 * Nombre : Jorge Alexander Castillo Niño y sebastian garcia 
 * Fecha : 07/03/2024
 * Tema : 
 * 
 */


public class Main {
    public static void main(String[] args) {
        Vista vista = new Vista();
        vista.ejecutar();
    }
}
