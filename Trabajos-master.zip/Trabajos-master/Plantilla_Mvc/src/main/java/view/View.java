package view;

/**
 *
 *
 * Nombre:Jorge Alexander Castillo Niño
 * Fecha  : 
 * Tema : 
 * 
 * 
 * 
 */
public class View {
    //Declaración de variables
    private String mensaje;
    
    //Metodo Constructor
    public View (){
        
        mensaje = "";
        
        
    }
    
    //Metodos Propios
    
    public void pedirNombre(){
        
        
        
        
    }
    
    
    public void pedirDatos(){
        
        
        
    }
    
    
    
}
