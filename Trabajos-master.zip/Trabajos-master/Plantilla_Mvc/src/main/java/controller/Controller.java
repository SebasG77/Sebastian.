package controller;

/**
 *
 *
 * Nombre:Jorge Alexander Castillo Niño
 * Fecha  : 
 * Tema : 
 * 
 * 
 * 
 */
public class Controller {
    //Declaración de variables
    
    //Metodo Constructor
    public Controller(){
        
        
        
        
        
    }
    
    //Metodos Propios
    
    
    
}
