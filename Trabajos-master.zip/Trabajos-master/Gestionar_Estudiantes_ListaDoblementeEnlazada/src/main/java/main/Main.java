package main;

import controller.ControladorGestionEstudiantes;


/**
 * Nombre : Jorge Alexander Castillo Niño
 * Fecha : 07/03/2024
 * Tema : Listas Doblemente Enlazadas
 */
public class Main {
    //Metodo Main
    public static void main(String[] args) {
    //Inicializar el controlador
        ControladorGestionEstudiantes controlador = new ControladorGestionEstudiantes();
        //Metodo para inciar el controlador
        System.out.println("Codigo By AlexN");
        controlador.ejecutar();
    }
       
    }
    
    
    
    

