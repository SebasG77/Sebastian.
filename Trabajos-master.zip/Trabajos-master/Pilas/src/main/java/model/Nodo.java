package model;

/**
 * Nombre : Jorge Alexander Castillo Niño
 * Tema : Pilas
 * Fecha : 2/04/2024
 */
public class Nodo {
    //Declaración de variables
    
    public char caracter;
    public Nodo siguiente;
    
    //Metodo Constructor
    public Nodo(int dato){
        
        this.caracter = caracter;
        this.siguiente = null;

       
    }
    
    
    
}
