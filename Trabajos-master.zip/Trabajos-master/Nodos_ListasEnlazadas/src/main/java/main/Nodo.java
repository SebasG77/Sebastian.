package main;

/**
 *Nombre: Jorge Alexander Castillo Niño
 *Fecha : 28/02/2024
 *Tema : Listas Enlazadas
 */
//Clase Lista Nodos


//Clase Nodo
public class Nodo{
  //Declarar variables
    
  int valor;
  Nodo siguiente;
  
  //Metodo Constructor
  public Nodo(int x) {
    valor = x;
  }
}


