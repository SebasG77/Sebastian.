package main;

import javax.swing.JOptionPane;
import view.RuletaVista;

/**
 *Nombre:Jorge Alexander Castillo Niño
 *Fecha:20/03/2024
 *Tema:Listas Circulares
 */
public class Main {
    //Metodo Main
     public static void main(String[] args) {
         //Inicializar vista
        RuletaVista vista = new RuletaVista();
        JOptionPane.showMessageDialog(null, "CODIGO BY ALEX");
        vista.ejecutar();
         
    }
}
