package model;

/**
 *Nombre:Jorge Alexander Castillo Niño
 *Fecha:20/03/2024
 *Tema:Listas Circulares
 */
public class Nodo {
    //Declaración de variables
    int dato;
    Nodo siguiente;

    //Metodo Constructor
    public Nodo(int dato) {
        //Inicializar variables
        this.dato = dato;
        this.siguiente = null;
    }
}
