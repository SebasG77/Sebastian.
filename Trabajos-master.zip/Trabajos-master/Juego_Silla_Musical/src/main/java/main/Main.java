package main;

import controller.Controlador;

/**
 *Nombre:Jorge Alexander Castillo Niño
 *Fecha:21/03/2024
 *Tema:Listas Circulares Listas 
 */
public class Main {
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        controlador.iniciarJuego();
    }
}